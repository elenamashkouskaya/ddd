#!/bin/bash
sudo ./hihi -R
echo OK!!!!
